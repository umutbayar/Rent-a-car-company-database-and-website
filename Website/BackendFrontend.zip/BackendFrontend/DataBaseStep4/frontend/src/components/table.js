import bootstrap from "bootstrap"
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from "axios";
import {useState} from "react";
import {Link, NavLink} from "react-router-dom";

export default function Table(props) {

    const [tableData,setTableData] = useState(props.data)


    return (
        <div className="container">
            <table className="table table-hover ">
                <thead>
                <tr>
                    {props.rows.map((row, i) => (
                        <th scope="col" key={i + row}>{row}</th>
                    ))}
                </tr>
                </thead>
                <tbody>

                {tableData.map((data, i) => (
                    <tr key={Math.floor(Math.random() * 4000)}>
                        {Object.keys(data).map((key, index) => {
                            if (index === 0){
                                return  (<td >
                                    <Link to={props.redirect_route + data[key]}> {data[key]}</Link>
                                </td>)
                            }else{
                                return  <td >{data[key]}</td>
                            }

                        })}

                    </tr>
                ))}

                </tbody>
            </table>
        </div>
    )
}