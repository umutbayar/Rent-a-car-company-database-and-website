import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function Cars() {
    const [cars, setCars] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/car/read")
            .then(res => setCars(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-car"}
                state={{
                    requested_route: "http://localhost:3000/api/car/create",
                    rows: ["LicencePlat"," Color", "Brand", "FuelType", "availableStartDate", "availableEndDate","price"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Car
                </button>
            </NavLink>

            {(() => {
                if (cars.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(cars[0])}
                            data={cars}
                            delete_route="http://localhost:3000/api/car/delete"
                            update_route="http://localhost:3000/api/car/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Car Records Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
