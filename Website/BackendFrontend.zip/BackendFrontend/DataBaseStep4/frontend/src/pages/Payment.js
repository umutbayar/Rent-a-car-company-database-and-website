import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function Payments() {
    const [payments, setPayments] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/payment/read")
            .then(res => setPayments(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-payment"}
                state={{
                    requested_route: "http://localhost:3000/api/payment/create",
                    rows: ["BillID", "OrderDate", "OrderAmount", "PaymentType", "TaxAmount"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Payment
                </button>
            </NavLink>

            {(() => {
                if (payments.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(payments[0])}
                            data={payments}
                            delete_route="http://localhost:3000/api/payment/delete"
                            update_route="http://localhost:3000/api/payment/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Payments Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
