import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function ReportsLine() {
    const [reportsLine, setReportsLine] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/reports-line/read")
            .then(res => setReportsLine(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-reports-line"}
                state={{
                    requested_route: "http://localhost:3000/api/reports-line/create",
                    rows: ["CustomerID", "ReportsID"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add ReportsLine
                </button>
            </NavLink>

            {(() => {
                if (reportsLine.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(reportsLine[0])}
                            data={reportsLine}
                            delete_route="http://localhost:3000/api/reports-line/delete"
                            update_route="http://localhost:3000/api/reports-line/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No ReportsLine Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
