import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function OrderLines() {
    const [orderLines, setOrderLines] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/order-line/read")
            .then(res => setOrderLines(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-order-line"}
                state={{
                    requested_route: "http://localhost:3000/api/order-line/create",
                    rows: ["CustomerID", "OrderID"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Order Line
                </button>
            </NavLink>

            {(() => {
                if (orderLines.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(orderLines[0])}
                            data={orderLines}
                            delete_route="http://localhost:3000/api/order-line/delete"
                            update_route="http://localhost:3000/api/order-line/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Order Lines Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
