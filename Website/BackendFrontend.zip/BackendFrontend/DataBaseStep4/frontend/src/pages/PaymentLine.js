import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function PaymentLines() {
    const [paymentLines, setPaymentLines] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/paymentLine/read")
            .then(res => setPaymentLines(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-payment-line"}
                state={{
                    requested_route: "http://localhost:3000/api/paymentLine/create",
                    rows: ["CustomerID", "BillID", "OrderID"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Payment Line
                </button>
            </NavLink>

            {(() => {
                if (paymentLines.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(paymentLines[0])}
                            data={paymentLines}
                            delete_route="http://localhost:3000/api/paymentLine/delete"
                            update_route="http://localhost:3000/api/paymentLine/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Payment Lines Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
