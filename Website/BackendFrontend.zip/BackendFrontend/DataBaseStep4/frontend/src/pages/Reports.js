import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function Reports() {
    const [reports, setReports] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/reports/read")
            .then(res => setReports(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-reports"}
                state={{
                    requested_route: "http://localhost:3000/api/reports/create",
                    rows: ["ReportsID", "ReportsContext", "ReportsDate"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Report
                </button>
            </NavLink>

            {(() => {
                if (reports.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(reports[0])}
                            data={reports}
                            delete_route="http://localhost:3000/api/reports/delete"
                            update_route="http://localhost:3000/api/reports/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Reports Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
