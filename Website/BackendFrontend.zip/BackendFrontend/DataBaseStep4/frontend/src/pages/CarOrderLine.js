import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function CarOrderLines() {
    const [carOrderLines, setCarOrderLines] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/car-order-line/read")
            .then(res => setCarOrderLines(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-car-order-line"}
                state={{
                    requested_route: "http://localhost:3000/api/car-order-line/create",
                    rows: ["OrderID", "LicencePlat", "CarType"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Car Order Line
                </button>
            </NavLink>

            {(() => {
                if (carOrderLines.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(carOrderLines[0])}
                            data={carOrderLines}
                            delete_route="http://localhost:3000/api/car-order-line/delete"
                            update_route="http://localhost:3000/api/car-order-line/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Car Order Lines Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
