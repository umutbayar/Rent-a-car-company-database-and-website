import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function CustomerAddresses() {
    const [customerAddresses, setCustomerAddresses] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/customer-address/read")
            .then(res => setCustomerAddresses(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-customer-address"}
                state={{
                    requested_route: "http://localhost:3000/api/customer-address/create",
                    rows: ["CustomerID", "Province", "District", "Street", "ApartmentNumber"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Customer Address
                </button>
            </NavLink>

            {(() => {
                if (customerAddresses.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(customerAddresses[0])}
                            data={customerAddresses}
                            delete_route="http://localhost:3000/api/customer-address/delete"
                            update_route="http://localhost:3000/api/customer-address/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Customer Addresses Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
