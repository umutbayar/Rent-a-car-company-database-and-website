import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function Customers() {
    const [customers, setCustomers] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/customer/read")
            .then(res => setCustomers(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-customer"}
                state={{
                    requested_route: "http://localhost:3000/api/customer/create",
                    rows: ["CustomerID", "FirstName", "LastName", "Mail", "Gender", "PhoneNumber"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Customer
                </button>
            </NavLink>

            {(() => {
                if (customers.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(customers[0])}
                            data={customers}
                            delete_route="http://localhost:3000/api/customer/delete"
                            update_route="http://localhost:3000/api/customer/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Customers Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
