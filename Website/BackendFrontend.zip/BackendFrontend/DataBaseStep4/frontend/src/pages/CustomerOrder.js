import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/navbar";
import Table from "../components/table";
import { NavLink } from "react-router-dom";

export default function CustomerOrders() {
    const [customerOrders, setCustomerOrders] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3000/api/customer-order/read")
            .then(res => setCustomerOrders(res.data.result))
            .catch((err) => {
                console.log(err);
            })
    }, []);

    return (
        <div>
            <Navbar></Navbar>

            <NavLink
                to={"/create-customer-order"}
                state={{
                    requested_route: "http://localhost:3000/api/customer-order/create",
                    rows: ["OrderID", "StartDate", "EndDate"],
                }}
            >
                <button type="button" className="btn btn-outline-primary btn-sm" style={{ marginLeft: 5, marginRight: 5 }}>
                    Add Customer Order
                </button>
            </NavLink>

            {(() => {
                if (customerOrders.length > 0) {
                    return (
                        <Table
                            rows={Object.keys(customerOrders[0])}
                            data={customerOrders}
                            delete_route="http://localhost:3000/api/customer-order/delete"
                            update_route="http://localhost:3000/api/customer-order/update"
                        ></Table>
                    )
                } else {
                    return (
                        <div className="alert alert-info" role="alert">
                            No Customer Orders Found!
                        </div>
                    )
                }
            })()}
        </div>
    );
}
