import './App.css';
//import bootstrap from "bootstrap"
//import 'bootstrap/dist/css/bootstrap.min.css';
import {Routes, Route} from "react-router-dom"

import NotFound from "./pages/NotFound";
import Car from "./pages/Car";
import CarOrderLine from "./pages/CarOrderLine";
import Customer from "./pages/Customer";
import CustomerAddress from "./pages/CustomerAddress";
import CustomerOrder from "./pages/CustomerOrder";
import OrderLine from "./pages/OrderLine";
import Payment from "./pages/Payment";
import PaymentLine from "./pages/PaymentLine";
import Reports from "./pages/Reports";
import ReportsLine from "./pages/ReportsLine";

function App() {
  return (
    <>
    <Routes>
      <Route path="/" element={<Car/>}></Route>
      <Route path="/Car" element={<Car/>}></Route>
      <Route path="/Customer" element={<Addresses/>}></Route>
      <Route path="/CustomerOrder" element={<CustomerOrder/>}></Route>
      <Route path="/CustomerOrder/:id" element={<OrderLine/>}></Route>
      <Route path="/Payment" element={<Payment/>}></Route>
      <Route path='*' element={<NotFound />}/>
    </Routes>
    </>
    
    
  );
}

export default App;
