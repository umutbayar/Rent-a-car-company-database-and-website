const express = require('express')

const Car_router = require('./Modules/Car.js')
const CarOrderLine_router=require('./Modules/CarOrderLine.js')
const Customer_router=require('./Modules/Customer.js')
const CustomerAddress_router=require('./Modules/CustomerAddress.js')
const CustomerOrder_router=require('./Modules/CustomerOrder.js')
const OrderLine_router=require('./Modules/OrderLine.js')
const Payment_router=require('./Modules/Payment.js')
const PaymentLine_router=require('./Modules/PaymentLine.js')
const Reports_router=require('./Modules/Reports.js')
const ReportsLine_router=require('./Modules/ReportsLine.js')
const router = express.Router()

const api_routes = router
    .get('/', function () {
    })
    
    .use('/Car',Car_router.routes)
    .use('CarOrderLine', CarOrderLine_router.routes)
    .use('/Customer',Customer_router.routes)
    .use('/CustomerAddress',CustomerAddress_router.routes)
    .use('/CustomerOrder',CustomerOrder_router.routes)
    .use('/OrderLine',OrderLine_router.routes)
    .use('/Payment',Payment_router.routes)
    .use('/PaymentLine',PaymentLine_router.routes)
    .use('/Reports',Reports_router.routes)
    .use('/ReportsLine',ReportsLine_router.routes)
    
exports.api_routes = api_routes