
const express = require('express')

const CustomerAddress_router = express.Router()

const {db} = require("../../db");


CustomerAddress_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from CustomerAddresses")
        res.status(200).json({
            "message": "tüm adresler listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

CustomerAddress_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const Province =String(req.body.inputs.Province)
        const District = String(req.body.inputs.District)
        const Street = String(req.body.inputs.Street)
        const ApartmentNumber = String(req.body.inputs.ApartmentNumber)

        let query = `INSERT INTO CustomerAddresses (CustomerID, Province, District, Street, ApartmentNumber)
            VALUES ('${CustomerID}', '${Province}', '${District}', '${Street}', '${ApartmentNumber}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni CustomerAddress oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
CustomerAddress_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const Province =String(req.body.inputs.Province)
        const District = String(req.body.inputs.District)
        const Street = String(req.body.inputs.Street)
        const ApartmentNumber = String(req.body.inputs.ApartmentNumber)
        let query = `update CustomerAddresses set  CustomerID ='${CustomerID}',Province = '${Province}',
        Street = '${Street}',ApartmentNumber = '${ApartmentNumber}'
         WHERE CustomerID  = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "CustomerAddress güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

CustomerAddress_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  CustomerAddresses where CustomerID = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "CustomerAddress silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = CustomerAddress_router

