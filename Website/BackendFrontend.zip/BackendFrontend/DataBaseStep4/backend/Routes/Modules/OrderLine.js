
const express = require('express')

const OrderLine_router = express.Router()

const {db} = require("../../db");


OrderLine_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from OrderLine")
        res.status(200).json({
            "message": "tüm Order listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

OrderLine_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const OrderID =String(req.body.inputs.OrderID)
        let query = `INSERT INTO OrderLinees (CustomerID, OrderID)
            VALUES ('${CustomerID}', '${OrderID}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni OrderLine oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
OrderLine_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const OrderID =String(req.body.inputs.OrderID)
        let query = `update OrderLine set  CustomerID ='${CustomerID}',OrderID = '${OrderID}',
            WHERE CustomerID  = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "OrderLine güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

OrderLine_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  OrderLine where CustomerID = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "OrderLine silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = OrderLine_router

