
const express = require('express')

const Reports_router = express.Router()

const {db} = require("../../db");


Reports_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from Reports")
        res.status(200).json({
            "message": "tüm Reports listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

Reports_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const ReportsID = parseInt(req.body.inputs.ReportsID)
        const ReportsContext =String(req.body.inputs.ReportsContext)
        const ReportsDate = new Date(req.body.inputs.ReportsDate)
        let query = `INSERT INTO Reports (ReportsID, ReportsContext, ReportsDate)
            VALUES ('${ReportsID}', '${ReportsContext}', '${ReportsDate}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni Reports oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
Reports_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const ReportsID = parseInt(req.body.inputs.ReportsID)
        const ReportsContext =String(req.body.inputs.ReportsContext)
        const ReportsDate = new Date(req.body.inputs.ReportsDate)
        let query = `update Reports set  ReportsID ='${ReportsID}',ReportsContext = '${ReportsContext}',
            ReportsDate='${ReportsDate}' WHERE ReportsID  = '${req.body.ReportsID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "Reports güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

Reports_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  Reports where ReportsID = '${req.body.ReportsID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "Reports silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = Reports_router

