
const express = require('express')

const ReportsLine_router = express.Router()

const {db} = require("../../db");


ReportsLine_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from ReportsLine")
        res.status(200).json({
            "message": "tüm ReportsLine listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

ReportsLine_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const ReportsID =parseInt(req.body.inputs.ReportsID)
        let query = `INSERT INTO ReportsLine (CustomerID, ReportsID)
            VALUES ('${CustomerID}', '${ReportsID}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni ReportsLine oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
ReportsLine_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const ReportsID =parseInt(req.body.inputs.ReportsID)
        let query = `update ReportsLine set  CustomerID ='${CustomerID}',ReportsID = '${ReportsID}',
             WHERE CustomerID  = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "ReportsLine güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

ReportsLine_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  ReportsLin where CustomerID = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "ReportsLine silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = ReportsLine_router

