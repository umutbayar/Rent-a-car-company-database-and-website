
const express = require('express')

const Payment_router = express.Router()

const {db} = require("../../db");


Payment_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from Payment")
        res.status(200).json({
            "message": "tüm ödemeler listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

Payment_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const BillID = parseInt(req.body.inputs.BillID)
        const OrderDate =new Date(req.body.inputs.OrderDate)
        const OrderAmount = parseInt(req.body.inputs.OrderAmount)
        const PaymentType = String(req.body.inputs.PaymentType)
        const TaxAmount = parseInt(req.body.inputs.TaxAmount)
        let query = `INSERT INTO Payment (BillID, OrderDate, OrderAmount
            ,PaymentType,TaxAmount)
            VALUES ('${BillID}', '${OrderDate}', '${OrderAmount}','${PaymentType}''${TaxAmount}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni Payment oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
Payment_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const BillID = parseInt(req.body.inputs.BillID)
        const OrderDate =new Date(req.body.inputs.OrderDate)
        const OrderAmount = parseInt(req.body.inputs.OrderAmount)
        const PaymentType = String(req.body.inputs.PaymentType)
        const TaxAmount = parseInt(req.body.inputs.TaxAmount)
        let query = `update Payment set  BillID ='${BillID}',OrderDate = '${OrderDate}',
            OrderAmount ='${OrderAmount}',PaymentType ='${PaymentType}',TaxAmount ='${TaxAmount}', WHERE BillID  = '${req.body.BillID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "Payment güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

Payment_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  Payment where BillID = '${req.body.BillID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "Payment silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = Payment_router

