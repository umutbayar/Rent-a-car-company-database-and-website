
const express = require('express')

const CustomerOrder_router = express.Router()

const {db} = require("../../db");


CustomerOrder_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from CustomerOrder")
        res.status(200).json({
            "message": "tüm order listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

CustomerOrder_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const OrderID = parseInt(req.body.inputs.OrderID)
        const StartDate =new Date(req.body.inputs.StartDate)
        const EndDate = new Date(req.body.inputs.EndDate)
        let query = `INSERT INTO CustomerOrder (OrderID, StartDate, EndDate)
            VALUES ('${OrderID}', '${StartDate}', '${EndDate}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni CustomerOrder oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
CustomerOrder_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const OrderID = parseInt(req.body.inputs.OrderID)
        const StartDate =new Date(req.body.inputs.StartDate);
        const EndDate = new Date(req.body.inputs.EndDate)
        let query = `update CustomerOrder set  OrderID ='${OrderID}',StartDate = '${StartDate}',
            EndDate ='${EndDate}' WHERE OrderID  = '${req.body.OrderID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "CustomerOrder güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

CustomerOrder_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  CustomerOrder where OrderID = '${req.body.OrderID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "CustomerOrder silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = CustomerOrder_router

