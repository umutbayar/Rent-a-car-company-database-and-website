
const express = require('express')

const PaymentLine_router = express.Router()

const {db} = require("../../db");


PaymentLine_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from PaymentLine")
        res.status(200).json({
            "message": "tüm PaymentLine listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

PaymentLine_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.City)
        const BillID =parseInt(req.body.inputs.BillID)
        const OrderID = parseInt(req.body.inputs.OrderID)
        let query = `INSERT INTO PaymentLine (CustomerID, BillID, OrderID)
            VALUES ('${CustomerID}', '${BillID}', '${OrderID}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni PaymentLine oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
PaymentLine_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const BillID =parseInt(req.body.inputs.BillID)
        const OrderID = parseInt(req.body.inputs.OrderID)
        let query = `update PaymentLine set  CustomerID ='${CustomerID}',BillID = '${BillID}',
            OrderID ='${OrderID}' WHERE CustomerID  = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "PaymentLine güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

PaymentLine_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  PaymentLine where CustomerID = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "PaymentLine silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = PaymentLine_router

