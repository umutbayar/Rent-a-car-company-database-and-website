
const express = require('express')

const CarOrderLine_router = express.Router()

const {db} = require("../../db");


CarOrderLine_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from CarOrderLine")
        res.status(200).json({
            "message": "tüm CarOrderLine listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

CarOrderLine_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const OrderID = parseInt(req.body.inputs.OrderID)
        const LicencePlat =String(req.body.inputs.LicencePlat)
        const CarType = String(req.body.inputs.CarType)
        let query = `INSERT INTO CarOrderLine (OrderID, LiicencePlat, CarType)
            VALUES ('${OrderID}', '${LicencePlat}', '${CarType}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni CarOrderLine oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
CarOrderLine_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const OrderID = parseInt(req.body.inputs.OrderID)
        const LicencePlat =String(req.body.inputs.LicencePlat)
        const CarType = String(req.body.inputs.CarType)
        let query = `update CarOrderLine set  OrderID ='${OrderID}', LicencePlat = '${LicencePlat}',
            CarType ='${CarType}' WHERE OrderID  = '${req.body.OrderID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "CarOrderLine güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

CarOrderLine_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  CarOrderLine where OrderID = '${req.body.OrderID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "CarOrderLine silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = CarOrderLine_router

