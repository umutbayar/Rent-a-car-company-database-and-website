const express = require('express');
const Car_router = express.Router();
const { db } = require("../../db");
const { VarChar } = require('msnodesqlv8');

Car_router.get('/read', async (req, res) => {
  try {
    const result = await db.query("SELECT * FROM Car");
    res.status(200).json({
      "message": "Tüm araçlar listelendi",
      "result": result.recordset
    });
  } catch (err) {
    console.error("Error while getting cars: ", err.message);
    res.status(400).json({
      "message": "Hata"
    });
  }
});

Car_router.post('/create', async (req, res) => {
  try {
    const LicencePlat = String(req.body.inputs.LicencePlat);
    const Color = String(req.body.inputs.Color);
    const Brand = String(req.body.inputs.Brand);
    const FuelType = String(req.body.inputs.FuelType);
    const availableStartDate = new Date(req.body.inputs.AvailableStartDate);
    const availableEndDate = new Date(req.body.inputs.availableEndDate);
    const price = parseInt(req.body.inputs.price);

    let query = `INSERT INTO Car (LicencePlat, Color, Brand, FuelType, availableStartDate, availableEndDate, price)
            VALUES ('${LicencePlat}', '${Color}', '${Brand}', '${FuelType}', '${availableStartDate}', '${availableEndDate}', ${price})`;

    const result = await db.query(query);
    res.status(201).json({
      "message": "Yeni araç oluşturuldu"
    });
  } catch (err) {
    console.error("Error while creating car: ", err.message);
    res.status(400).json({
      "message": "Hata",
      "err": err.message
    });
  }
});

Car_router.put('/update', async (req, res) => {
  try {
    const LicencePlat = String(req.body.inputs.LicencePlat);
    const Color = String(req.body.inputs.Color);
    const Brand = String(req.body.inputs.Brand);
    const FuelType = String(req.body.inputs.FuelType);
    const availableStartDate = new Date(req.body.inputs.AvailableStartDate);
    const availableEndDate = new Date(req.body.inputs.availableEndDate);
    const price = parseInt(req.body.inputs.price);
    let query = `
        UPDATE Car
        SET
          Color = '${Color}',
          Brand = '${Brand}',
          FuelType = '${FuelType}',
          availableStartDate = '${availableStartDate}',
          availableEndDate = '${availableEndDate}',
          price = ${price}
        WHERE LicencePlat = '${LicencePlat}'`;

    const result = await db.query(query);

    res.status(201).json({
      "message": "Araç güncellendi"
    });
  } catch (err) {
    console.error("Error while updating car: ", err.message);
    res.status(400).json({
      "message": "Hata",
      "err": err.message
    });
  }
});

Car_router.delete('/delete', async (req, res) => {
  try {
    const LicencePlat = String(req.body.LicencePlat);
    let query = `DELETE FROM Car WHERE LicencePlat = '${LicencePlat}'`;
    const result = await db.query(query);
    res.status(201).json({
      "message": "Araç silindi"
    });
  } catch (err) {
    console.error("Error while deleting car: ", err.message);
    res.status(400).json({
      "message": "Hata",
      "err": err.message
    });
  }
});

exports.routes = Car_router;
