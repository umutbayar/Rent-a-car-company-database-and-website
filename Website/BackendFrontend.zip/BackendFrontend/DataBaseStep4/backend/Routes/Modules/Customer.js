
const express = require('express')

const Customer_router = express.Router()

const {db} = require("../../db");


Customer_router.get('/read', async (req, res) => {

    try {
        const result = await db.query("select * from Customer")
        res.status(200).json({
            "message": "tüm Customer listelendi",
            "result" : result.recordset
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata"
        })
    }

})

Customer_router.post('/create',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const FirstName =String(req.body.inputs.FirstName)
        const LastName = String(req.body.inputs.LastName)
        const Mail = String(req.body.inputs.Mail)
        const Gender = String(req.body.inputs.Gender)
        const PhoneNumber = String(req.body.inputs.PhoneNumber)
        let query = `INSERT INTO Customer (CustomerID, FirstName, LastName, Mail, Gender, PhoneNumber)
            VALUES ('${CustomerID}', '${FirstName}','${LastName}','${Mail}','${Gender}', '${PhoneNumber}')`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "yeni Customer oluşturuldu"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})
Customer_router.put('/update',  async (req, res) => {
    try {
        console.log(req.body)
        const CustomerID = parseInt(req.body.inputs.CustomerID)
        const FirstName =String(req.body.inputs.FirstName)
        const LastName = String(req.body.inputs.LastName)
        const Mail = String(req.body.inputs.Mail)
        const Gender = String(req.body.inputs.Gender)
        const PhoneNumber = String(req.body.inputs.PhoneNumber)
        let query = `update Customer set  sName ='${CustomerID}',
        '${FirstName}','${LastName}','${Mail}','${Gender}',
        '${PhoneNumber}' WHERE CustomerID  = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "Customer güncellendi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})

Customer_router.delete('/delete',  async (req, res) => {
    try {
        let query = `DELETE from  Customer where CustomerID = '${req.body.CustomerID}'`;
        const result = await db.query(query)
        res.status(201).json({
            "message": "Customer silindi"
        })
    } catch (err) {
        console.error(`Error while getting programming languages `, err.message);
        res.status(400).json({
            "message": "hata",
            "err" : err.message
        })
    }

})


exports.routes = Customer_router

